//
//  AppDelegate.h
//  PhotonFECT
//
//  Created by Suju on 7/1/19.
//  Copyright © 2019 Suju. All rights reserved.
//

#import <UIKit/UIKit.h>
@class BLEManager;

@interface AppDelegate : UIResponder <UIApplicationDelegate>
@property (strong, nonatomic) UIWindow *window;

@end

