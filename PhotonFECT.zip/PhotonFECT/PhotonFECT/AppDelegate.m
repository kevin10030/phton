//
//  AppDelegate.m
//  PhotonFECT
//
//  Created by Suju on 7/1/19.
//  Copyright © 2019 Suju. All rights reserved.
//

#import "AppDelegate.h"
#import "PhotonFECT-Swift.h"
#import "MainViewController.h"
#import "MMDrawerController.h"
#import "DrawerViewController.h"
#import "MMDrawerVisualState.h"
#import "Preference.h"
#import "Constants.h"
#import "LocalizeHelper.h"

@interface AppDelegate ()
@property (nonatomic,strong) MMDrawerController * drawerController;
@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    [[BLEManager getSharedBLEManager] initCentralManagerWithQueue:dispatch_get_main_queue() options:nil ];
    
    Preference* pref = [Preference getInstance];
    int row =  [pref getSharedPreference:nil :PREF_LANGUAGE WithINT:0];
    LocalizationSetLanguage(LANGUAGE_LOCALE[row]);
    
//    int veryfirst_flag =  [pref getSharedPreference:nil :PREF_VERYFIRST_FLAG WithINT:0];
    
    
//    CGRect screenRect = [[UIScreen mainScreen] bounds];
////    CGFloat screenWidth = screenRect.size.width;
//    CGFloat screenHeight = screenRect.size.height;
//    
//    // 1. Initialize window
//    self.window = [[UIWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
//    // 2. Get storyboard
//    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
//    // 3. Create vc
//    
//    UINavigationController *navViewController = [storyboard instantiateViewControllerWithIdentifier:@"NavigationController"];
//    
//    //MainViewController *mainViewController = [storyboard instantiateViewControllerWithIdentifier:NSStringFromClass([MainViewController class])];
//    DrawerViewController *drawerViewController = [storyboard instantiateViewControllerWithIdentifier:NSStringFromClass([DrawerViewController class])];
//    
//    [drawerViewController.view setFrame:CGRectMake(0, 0, 240, screenHeight)];
//    
//    self.drawerController = [[MMDrawerController alloc]
//                             initWithCenterViewController:navViewController
//                             leftDrawerViewController:drawerViewController];
//    
//    [self.drawerController setShowsShadow:NO];
//    [self.drawerController setRestorationIdentifier:@"MMDrawer"];
//    [self.drawerController setMaximumLeftDrawerWidth:240];
//    [self.drawerController setOpenDrawerGestureModeMask:MMOpenDrawerGestureModeAll];
//    [self.drawerController setCloseDrawerGestureModeMask:MMCloseDrawerGestureModeAll];
//    
//    //[self.drawerController setDrawerVisualStateBlock:[MMDrawerVisualState slideAndScaleVisualStateBlock]];
//    // 4. Set as root
//    self.window.rootViewController = self.drawerController;
//    // 5. Call to show views
//    [self.window makeKeyAndVisible];
    
    return YES;
}


- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}


- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}


@end
