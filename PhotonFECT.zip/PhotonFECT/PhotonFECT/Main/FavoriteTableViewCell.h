//
//  FavoriteTableViewCell.h
//  PhotonFECT
//
//  Created by Suju on 9/27/19.
//  Copyright © 2019 Suju. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ItemModel.h"
#import "FavoritesViewController.h"

@interface FavoriteTableViewCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *lblName;
@property (nonatomic, retain) ItemModel *itemModel;
@property (nonatomic, retain) FavoritesViewController *parent;
@end
