//
//  BioInfoViewController.m
//  PhotonFECT
//
//  Created by Suju on 7/2/19.
//  Copyright © 2019 Suju. All rights reserved.
//

#import "FavoritesViewController.h"
#import "LocalizeHelper.h"
#import "DBManager.h"
#import "FavoriteTableViewCell.h"
#import "SWRevealViewController.h"

static NSString * const kFavoritesTableViewCellIdentifier = @"FavoritesTableViewCell";

@interface FavoritesViewController ()

@end

@implementation FavoritesViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [lblTitle setText:LocalizedString(@"Favorite")];
    favoriteArray = [[DBManager getSharedInstance] findAllFavorites];
}

-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    [self reloadTable];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



- (IBAction)onClickClose:(id)sender {
    UIViewController *vc = [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"NavigationController"];
    [self.revealViewController pushFrontViewController:vc animated:YES];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
- (void) reloadTable
{
    favoriteArray = [[DBManager getSharedInstance] findAllFavorites];
    [tvFavorites reloadData];
}

#pragma mark - UITableViewDelegate Protocol

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    NSAssert(tvFavorites == tableView, LocalizedString(@"Unknown table view"));
    if (tvFavorites == tableView) {
        if([indexPath section] == 0)
        {
            [tvFavorites deselectRowAtIndexPath:indexPath animated:YES];
//            ItemModel *item = [favoriteArray objectAtIndex:indexPath.row];
        }
    }
}
#pragma mark - UITableViewDataSource Protocol

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    NSInteger sections = 0;
    
    NSAssert(tvFavorites == tableView, LocalizedString(@"Unknown table view"));
    if (tvFavorites == tableView) {
        sections = 1;
    }
    return sections;
}

- (NSInteger)tableView:(UITableView *)tableView
 numberOfRowsInSection:(NSInteger)section
{
    NSInteger rows = 0;
    
    NSAssert(tvFavorites == tableView, LocalizedString(@"Unknown table view"));
    if (tvFavorites == tableView) {
        if(section == 0) {
            return [favoriteArray count];
        }
    }
    return rows;
}

- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(nonnull NSIndexPath *)indexPath
{
    FavoriteTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:kFavoritesTableViewCellIdentifier];
    if (cell == nil) {
        cell = [[FavoriteTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                      reuseIdentifier:kFavoritesTableViewCellIdentifier];
    }
    
    NSAssert(tvFavorites == tableView, LocalizedString(@"Unknown table view"));
    if (tvFavorites == tableView) {
        if([indexPath section] == 0)
        {
            ItemModel *item = [favoriteArray objectAtIndex:indexPath.row];
            [cell.lblName setText:[NSString stringWithFormat:@"%@(%@)", item.name,item.color]];
            cell.itemModel = item;
            cell.parent = self;
        }
    }
    return cell;
}
@end
