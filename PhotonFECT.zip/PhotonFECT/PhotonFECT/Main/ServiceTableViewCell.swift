//
//  ServiceTableViewCell.swift
//  BLE_Demo
//
//  Created by Suju
//

import UIKit

class ServiceTableViewCell: UITableViewCell {
    @IBOutlet weak var serviceNameLbl: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
