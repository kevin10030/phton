//
//  ExpertViewController.m
//  PhotonFECT
//
//  Created by Suju on 8/1/19.
//  Copyright © 2019 Suju. All rights reserved.
//

#import "ExpertViewController.h"
#import "NewTaskViewController.h"
#import "Utility.h"
#import "Constants.h"
#import "Preference.h"
#import "PhotonFECT-Swift.h"
#import "LocalizeHelper.h"
#import "DBManager.h"
#import "SWRevealViewController.h"

static NSString * const kExpertTableViewCellIdentifier = @"ExpertTableViewCell";
static NSString * const kExpertItemsHeaderTitle = @"Items";
static NSString * const kExpertGroupsHeaderTitle = @"Groups";

@interface ExpertViewController ()<PropertiesDelegate>
{
    BLEDeviceProperties *bleCharProperties;
    
    CBPeripheral *currentPeripheral;
    CBService *currentService;
    CBCharacteristic *currentCharacteristic;
}
@end

@implementation ExpertViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    bleCharProperties = [[BLEDeviceProperties alloc] init];
    bleCharProperties.delegate = self;
    
    currentPeripheral = [Utility getCurrentPeripheral];
    currentService = [Utility getCurrentService];
    currentCharacteristic = [Utility getCurrentCharacteristic];
    
    
    if(self.gropModel == nil) {
        [self doSomethingWithTheJson];
        [lbTitle setText:LocalizedString(@"Expert Database")];
    } else {
        [lbTitle setText:self.gropModel.name];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)doSomethingWithTheJson
{
    NSDictionary *dict = [self JSONFromFile];
    self.gropModel = [[GroupModel alloc] initWithDictionary:dict];
    

}

- (NSDictionary *)JSONFromFile
{
    Preference* pref = [Preference getInstance];
    int row =  [pref getSharedPreference:nil :PREF_LANGUAGE WithINT:0];
    NSString *jsonTitle = @"expert";
    if(row == 1) jsonTitle = @"expert_cn";
    else if(row == 2) jsonTitle = @"expert_tw";
        
    NSString *path = [[NSBundle mainBundle] pathForResource:jsonTitle ofType:@"json"];
    NSData *data = [NSData dataWithContentsOfFile:path];
    return [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:nil];
}

- (IBAction)onClickClose:(id)sender {
    if (self.revealViewController != NULL) {
        UIViewController *vc = [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"NavigationController"];
//        [self.revealViewController pushFrontViewController:vc animated:YES];
        [self dismissViewControllerAnimated:YES completion:nil];
    } else {
        [self dismissViewControllerAnimated:YES completion:^{
        }];
    }
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

-(void)gotoScreen:(GroupModel *)group
{
    CATransition* transition = [CATransition animation];
    transition.duration = 0.3;
    transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseOut];
    transition.type = kCATransitionPush;
    transition.subtype = kCATransitionFromRight;
    
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    ExpertViewController *destViewController = [storyboard instantiateViewControllerWithIdentifier:@"ExpertViewController"];
    destViewController.gropModel = group;
    [destViewController.view.layer addAnimation:transition forKey:kCATransition];
    [self presentViewController:destViewController animated:YES completion:nil];
//    [self.revealViewController pushFrontViewController:destViewController animated:YES];
}

-(void)gotoNewTaskScreen:(ItemModel *)item
{
    CATransition* transition = [CATransition animation];
    transition.duration = 0.3;
    transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseOut];
    transition.type = kCATransitionPush;
    transition.subtype = kCATransitionFromRight;
    
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    NewTaskViewController *destViewController = [storyboard instantiateViewControllerWithIdentifier:@"NewTaskViewController"];
    destViewController.itemModel = item;
    destViewController.modalPresentationStyle = UIModalPresentationFullScreen;
    [destViewController.view.layer addAnimation:transition forKey:kCATransition];
    [self presentViewController:destViewController animated:YES completion:nil];
//    [self.revealViewController pushFrontViewController:destViewController animated:YES];
}

#pragma mark - UITableViewDelegate Protocol

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSAssert(tvExpert == tableView, LocalizedString(@"Unknown table view"));
    if (tvExpert == tableView) {
        if([indexPath section] == 0)
        {
//            ItemModel *item = [[self.gropModel itemArray] objectAtIndex:indexPath.row];
//            [self gotoNewTaskScreen:item];
            
            Preference* pref = [Preference getInstance];
            if([pref getSharedPreference:nil :PREF_VERYFIRST_FLAG WithBOOL:false])
            {
                ItemModel *item = [[self.gropModel itemArray] objectAtIndex:indexPath.row];
                [self gotoNewTaskScreen:item];
            } else {
                [[Utility getInstance] showToastMessage:LocalizedString(@"Please connect to 5CH device First!")];
            }
            
//            if([pref getSharedPreference:nil :PREF_CONNECTION_STATUS WithBOOL:false])
//            {
//                if(currentCharacteristic == nil) {
//                    [[Utility getInstance] showToastMessage:LocalizedString(@"Please select characteristic")];
//                } else {
//                    ItemModel *item = [[self.gropModel itemArray] objectAtIndex:indexPath.row];
//                    [self gotoNewTaskScreen:item];
//                }
//            } else {
//                [[Utility getInstance] showToastMessage:LocalizedString(@"Please connect to 5CH device First!")];
//            }
        } else {
            GroupModel *group = [[self.gropModel groupArray] objectAtIndex:indexPath.row];
            [self gotoScreen:group];
        }
    }
}

#pragma mark - UITableViewDataSource Protocol

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    NSInteger sections = 0;
    
    NSAssert(tvExpert == tableView, LocalizedString(@"Unknown table view"));
    if (tvExpert == tableView) {
        sections = 2;
    }
    return sections;
}

- (NSInteger)tableView:(UITableView *)tableView
 numberOfRowsInSection:(NSInteger)section
{
    NSInteger rows = 0;
    
    NSAssert(tvExpert == tableView, LocalizedString(@"Unknown table view"));
    if (tvExpert == tableView) {
        if(section == 0) {
            rows = [[self.gropModel itemArray] count];
        } else {
            rows = [[self.gropModel groupArray] count];
        }
    }
    return rows;
}

- (NSString *)tableView:(UITableView *)tableView
titleForHeaderInSection:(NSInteger)section
{
    NSString *headerTitle = @"";
    if (section == 0) {
        headerTitle = LocalizedString(kExpertItemsHeaderTitle);
    } else {
        headerTitle = LocalizedString(kExpertGroupsHeaderTitle);
    }
    return headerTitle;
}

- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(nonnull NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:kExpertTableViewCellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                      reuseIdentifier:kExpertTableViewCellIdentifier];
    }
    
    NSAssert(tvExpert == tableView, LocalizedString(@"Unknown table view"));
    if (tvExpert == tableView) {
        
        if([indexPath section] == 0)
        {
            if ([[self.gropModel itemArray] count] > indexPath.row) {
                ItemModel *item = [[self.gropModel itemArray] objectAtIndex:indexPath.row];
                if ([item isKindOfClass:[ItemModel class]]) {
                    if([item.desc isEqualToString:@""])
                        cell.textLabel.text = item.name;
                    else
                        cell.textLabel.text = [NSString stringWithFormat:@"%@ (%@)", item.name,item.desc];
                }
            }
        } else {
            if ([[self.gropModel groupArray] count] > indexPath.row) {
                GroupModel *group = [[self.gropModel groupArray] objectAtIndex:indexPath.row];
                if ([group isKindOfClass:[GroupModel class]]) {
                    cell.textLabel.text = [NSString stringWithFormat:@"%@", group.name];
                }
            }
        }
    }
    return cell;
}


//PropertiesDelegate
-(void)postWriteCharacteristicValueWithPeripheral:(CBPeripheral *)peripheral char:(CBCharacteristic *)char_
{
    
}

-(void)postWriteCharacteristicValueFailedWithError:(NSError *)error
{
    @try{
        [[Utility getInstance] showToastMessage:[NSString stringWithFormat:@"WriteError - %@", [error localizedDescription]]];
    }@catch (NSException *exception) {}
}

-(void)postReadCharacteristicValueWithPeripheral:(CBPeripheral *)peripheral char:(CBCharacteristic *)char_
{
    //NSData *data = char_.value;
    //NSString *readStr = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    // [[Utility getInstance] showToastMessage:readStr];
}

-(void)postReadCharacteristicValueFailedWithError:(NSError *)error
{
    /* @try{
     [[Utility getInstance] showToastMessage:[NSString stringWithFormat:@"%@ReadError - %@", [error localizedDescription]]];
     }@catch (NSException *exception) {}
     */
}

@end
