//
//  AboutViewController.m
//  PhotonFECT
//
//  Created by Suju on 9/30/19.
//  Copyright © 2019 Suju. All rights reserved.
//

#import "AboutViewController.h"
#import "LocalizeHelper.h"
#import "Preference.h"
#import "Constants.h"
#import "SWRevealViewController.h"

@interface AboutViewController ()

@end

@implementation AboutViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [lblTitle setText:LocalizedString(@"About")];
    
    Preference* pref = [Preference getInstance];
    int row =  [pref getSharedPreference:nil :PREF_LANGUAGE WithINT:0];
    NSString *contentTitle = @"about_en";
    if(row == 1) contentTitle = @"about_cn";
    else if(row == 2) contentTitle = @"about_tw";
    
    NSString *path = [[NSBundle mainBundle] pathForResource:contentTitle ofType:@"txt"];
    NSString* content = [NSString stringWithContentsOfFile:path
                                                  encoding:NSUTF8StringEncoding
                                                     error:NULL];
    content = [NSString stringWithFormat:@"&emsp;%@",content];
    
    //uiWebView.dataDetectorTypes =  UIDataDetectorTypeNone;
    [uiWebView loadHTMLString:[content stringByReplacingOccurrencesOfString:@"\n" withString:@"<br/>&emsp;"] baseURL:nil];
}

- (IBAction)onClickClose:(id)sender {
    UIViewController *vc = [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"NavigationController"];
    [self.revealViewController pushFrontViewController:vc animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
