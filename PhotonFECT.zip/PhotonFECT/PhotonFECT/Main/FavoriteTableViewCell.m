//
//  FavoriteTableViewCell.m
//  PhotonFECT
//
//  Created by Suju on 9/27/19.
//  Copyright © 2019 Suju. All rights reserved.
//

#import "FavoriteTableViewCell.h"
#import "DBManager.h"
#import "NewTaskViewController.h"
#import "Utility.h"
#import "Constants.h"
#import "Preference.h"
#import "LocalizeHelper.h"

@implementation FavoriteTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
- (IBAction)onClickEdit:(id)sender {
    
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:LocalizedString(@"Favorite")
                                                                   message:LocalizedString(@"Enter color scheme name below")
                                                            preferredStyle:UIAlertControllerStyleAlert];

    UIAlertAction *submit = [UIAlertAction actionWithTitle:LocalizedString(@"Save") style:UIAlertActionStyleDefault
                                                   handler:^(UIAlertAction * action) {
                                                       
                                                       if (alert.textFields.count > 0) {
                                                           UITextField *textField = [alert.textFields firstObject];
                                                           if(textField.text.length > 0) {
                                                               self.itemModel.name =  textField.text;
                                                               [[DBManager getSharedInstance] updateFavorite:self.itemModel];
                                                               [self.parent reloadTable];
                                                           }
                                                       }
                                                   }];
    
    UIAlertAction *cancel = [UIAlertAction actionWithTitle:LocalizedString(@"Cancel") style:UIAlertActionStyleCancel handler:nil];
    
    [alert addAction:submit];
    [alert addAction:cancel];
    [alert addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.placeholder = LocalizedString(@"Color Scheme Name"); // if needs
        textField.text = self.itemModel.name;
    }];
    
    [self.parent presentViewController:alert animated:YES completion:nil];
}

-(void)gotoNewTaskScreen:(ItemModel *)item
{
    CATransition* transition = [CATransition animation];
    transition.duration = 0.3;
    transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseOut];
    transition.type = kCATransitionPush;
    transition.subtype = kCATransitionFromRight;
    
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    NewTaskViewController *destViewController = [storyboard instantiateViewControllerWithIdentifier:@"NewTaskViewController"];
    destViewController.itemModel = item;
    destViewController.modalPresentationStyle = UIModalPresentationFullScreen;
    [destViewController.view.layer addAnimation:transition forKey:kCATransition];
    [self.parent presentViewController:destViewController animated:YES completion:nil];
}

- (IBAction)onClickExecute:(id)sender {
    [self gotoNewTaskScreen:self.itemModel];
//    Preference* pref = [Preference getInstance];
//    if([pref getSharedPreference:nil :PREF_CONNECTION_STATUS WithBOOL:false])
//    {
//        if([Utility getCurrentCharacteristic] == nil) {
//            [[Utility getInstance] showToastMessage:LocalizedString(@"Please select characteristic")];
//        } else {
//            [self gotoNewTaskScreen:self.itemModel];
//        }
//    } else {
//        [[Utility getInstance] showToastMessage:LocalizedString(@"Please connect to 5CH device First!")];
//    }
}

- (IBAction)onClickRemove:(id)sender {
    [[DBManager getSharedInstance] removeFavorite:self.itemModel];
    [self.parent reloadTable];
}


@end
