//
//  BioInfoViewController.h
//  PhotonFECT
//
//  Created by Suju on 7/2/19.
//  Copyright © 2019 Suju. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FavoritesViewController : UIViewController<UITableViewDelegate,UITableViewDataSource>
{
    IBOutlet UILabel *lblTitle;
    IBOutlet UITableView *tvFavorites;
    
    NSArray* favoriteArray;
}
- (void) reloadTable;

@end
