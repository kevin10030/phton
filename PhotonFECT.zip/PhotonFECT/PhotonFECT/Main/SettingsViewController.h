//
//  SettingsViewController.h
//  PhotonFECT
//
//  Created by Suju on 8/6/19.
//  Copyright © 2019 Suju. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RadioButton.h"

@interface SettingsViewController : UIViewController<UIPickerViewDelegate,UIPickerViewDataSource>
{
    IBOutlet UIPickerView *pickerSelLang;
    IBOutlet UILabel *lblTitle;
    IBOutlet UILabel *lblSeleLang;
    IBOutlet UIButton *btnSave;
    
    IBOutlet UIImageView *imgClose;
    IBOutlet UIButton *btnClose;
    
    IBOutlet UILabel *lblDeviceWearingLocation;

    IBOutlet RadioButton *btnLeftHandPalm;
    IBOutlet RadioButton *btnLeftHandBack;    
}


@end
