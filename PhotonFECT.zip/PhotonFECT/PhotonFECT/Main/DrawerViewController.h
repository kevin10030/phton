//
//  DrawerViewController.h
//  PhotonFECT
//
//  Created by Suju on 7/1/19.
//  Copyright © 2019 Suju. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DrawerViewController : UIViewController
{
    IBOutlet UILabel *ulWelcome;
    IBOutlet UIButton *btnLogout;
    IBOutlet UILabel *lblHome;
    IBOutlet UILabel *lblFavorites;
    IBOutlet UILabel *lblNewTask;
    IBOutlet UILabel *lblExpertDatabase;
    IBOutlet UILabel *lblSettings;
    IBOutlet UILabel *lblHelp;    
    IBOutlet UILabel *lblAbout;
    
    
}
@end
