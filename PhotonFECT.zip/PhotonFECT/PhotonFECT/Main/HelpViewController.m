//
//  HelpViewController.m
//  PhotonFECT
//
//  Created by Suju on 9/30/19.
//  Copyright © 2019 Suju. All rights reserved.
//

#import "HelpViewController.h"
#import "LocalizeHelper.h"
#import "SWRevealViewController.h"
#import "Preference.h"
#import "Constants.h"

@interface HelpViewController ()

@end

@implementation HelpViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [lblTitle setText:LocalizedString(@"Help")];
    
    Preference* pref = [Preference getInstance];
    int row =  [pref getSharedPreference:nil :PREF_LANGUAGE WithINT:0];
    NSString *contentTitle = @"help_en";
    if(row == 1) contentTitle = @"help_cn";
    else if(row == 2) contentTitle = @"help_tw";
    
    NSString *path = [[NSBundle mainBundle] pathForResource:contentTitle ofType:@"txt"];
    NSString* content = [NSString stringWithContentsOfFile:path
                                                  encoding:NSUTF8StringEncoding
                                                     error:NULL];
    content = [NSString stringWithFormat:@"&emsp;%@",content];
    
    //uiWebView.dataDetectorTypes =  UIDataDetectorTypeNone;
    [uiWebView loadHTMLString:[content stringByReplacingOccurrencesOfString:@"\n" withString:@"<br/>&emsp;"] baseURL:nil];
}

- (IBAction)onClickClose:(id)sender {
    UIViewController *vc = [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"NavigationController"];
    [self.revealViewController pushFrontViewController:vc animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
