//
//  DrawerViewController.m
//  PhotonFECT
//
//  Created by Suju on 7/1/19.
//  Copyright © 2019 Suju. All rights reserved.
//

#import "DrawerViewController.h"
#import "UIViewController+MMDrawerController.h"
#import "Utility.h"
#import "LocalizeHelper.h"
#import "SWRevealViewController.h"

@interface DrawerViewController ()

@end

@implementation DrawerViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initText];
}

-(void)viewDidAppear:(BOOL) animated {
    [super viewDidAppear:animated];
    [self initText];
}

-(void)initText
{
    [ulWelcome setText:LocalizedString(@"Welcome")];
    [btnLogout setTitle:LocalizedString(@"logout") forState:UIControlStateNormal];
    [lblHome setText:LocalizedString(@"Home")];
    [lblFavorites setText:LocalizedString(@"Favorite")];
    [lblNewTask setText:LocalizedString(@"New Task")];
    [lblExpertDatabase setText:LocalizedString(@"Expert Database")];
    [lblSettings setText:LocalizedString(@"Settings")];
    [lblHelp setText:LocalizedString(@"Help")];
    [lblAbout setText:LocalizedString(@"About")];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)onClickLogout:(id)sender {
    [[Utility getInstance] LogOut:self];
}

- (IBAction)onClickHome:(id)sender {
    UIViewController *vc = [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"NavigationController"];
    [self.revealViewController pushFrontViewController:vc animated:YES];
//    [self.revealViewController revealToggle:sender];
}

- (IBAction)onClickFavorites:(id)sender {   
    UIViewController *vc = [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"FavoritesViewController"];
    [self.revealViewController pushFrontViewController:vc animated:YES];
//    [self presentViewController:vc animated:YES completion:nil];
}

- (IBAction)onClickNewTask:(id)sender {
    UIViewController *vc = [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"NewTaskViewController"];
    [self.revealViewController pushFrontViewController:vc animated:YES];
//    [self presentViewController:vc animated:YES completion:nil];
}

- (IBAction)onClickExpertDatabase:(id)sender {
    CATransition* transition = [CATransition animation];
    transition.duration = 0.3;
    transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseOut];
    transition.type = kCATransitionPush;
    transition.subtype = kCATransitionFromRight;
    
    UIViewController *vc = [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"ExpertViewController"];
//    [self.revealViewController pushFrontViewController:vc animated:YES];
    [self.revealViewController revealToggle:sender];
    vc.modalPresentationStyle = UIModalPresentationFullScreen;
    [vc.view.layer addAnimation:transition forKey:kCATransition];
    [self presentViewController:vc animated:NO completion:nil];
}

- (IBAction)onClickSettings:(id)sender {
    UIViewController *vc = [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"SettingsViewController"];
    [self.revealViewController pushFrontViewController:vc animated:YES];
//    [self presentViewController:vc animated:YES completion:nil];
}

- (IBAction)onClickHelp:(id)sender {
    UIViewController *vc = [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"HelpViewController"];
    [self.revealViewController pushFrontViewController:vc animated:YES];
//    [self presentViewController:vc animated:YES completion:nil];
}

- (IBAction)onClickAbout:(id)sender {
    UIViewController *vc = [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"AboutViewController"];
     [self.revealViewController pushFrontViewController:vc animated:YES];
 //    [self presentViewController:vc animated:YES completion:nil];
}





/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
