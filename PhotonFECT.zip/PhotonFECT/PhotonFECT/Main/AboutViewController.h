//
//  AboutViewController.h
//  PhotonFECT
//
//  Created by Suju on 9/30/19.
//  Copyright © 2019 Suju. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <WebKit/WebKit.h>

@interface AboutViewController : UIViewController
{
    IBOutlet UILabel *lblTitle;
    IBOutlet WKWebView *uiWebView;
}
@end
