//
//  SettingsViewController.m
//  PhotonFECT
//
//  Created by Suju on 8/6/19.
//  Copyright © 2019 Suju. All rights reserved.
//

#import "SettingsViewController.h"
#import "Preference.h"
#import "Constants.h"
#import "LocalizeHelper.h"
#import "AppDelegate.h"
#import "DrawerViewController.h"
#import "MMDrawerController.h"
#import "MMDrawerVisualState.h"
#import "SWRevealViewController.h"

@interface SettingsViewController ()

@end

@implementation SettingsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    Preference* pref = [Preference getInstance];
    int row =  [pref getSharedPreference:nil :PREF_LANGUAGE WithINT:0];
    [pickerSelLang selectRow:(NSInteger)row inComponent:0 animated:TRUE];
    
    row =  [pref getSharedPreference:nil :PREF_HAND_LOCATION WithINT:0];
    if(row == 0) {
        btnLeftHandPalm.selected = true;
        btnLeftHandBack.selected = false;
    } else {
        btnLeftHandPalm.selected = false;
        btnLeftHandBack.selected = true;
    }
    
    [btnLeftHandPalm setTitle:LocalizedString(@"Left Hand Palm/Right Hand Back") forState:UIControlStateNormal];
    [btnLeftHandBack setTitle:LocalizedString(@"Left Hand Back/Right Hand Palm") forState:UIControlStateNormal];
    
    [lblTitle setText:LocalizedString(@"Settings")];
    [lblSeleLang setText:LocalizedString(@"Please select language")];
    [lblDeviceWearingLocation setText:LocalizedString(@"Device Wearing Location")];
    [btnSave setTitle:LocalizedString(@"Save") forState:UIControlStateNormal];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (IBAction)onClickHandPalm:(id)sender {
    //btnLeftHandPalm.selected = true;
    //btnLeftHandBack.selected = false;
}
- (IBAction)onClickHandBack:(id)sender {
    //btnLeftHandPalm.selected = false;
    //btnLeftHandBack.selected = true;
}

-(void)onClose {
    if(self.revealViewController == NULL) {
        AppDelegate* appDelegate;
        appDelegate = (AppDelegate*)[[UIApplication sharedApplication]delegate];
        UIViewController *vc = [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"SWRevealViewController"];
        [appDelegate.window setRootViewController:vc];
        [self dismissViewControllerAnimated:YES completion:nil];
    } else {
        UIViewController *vc = [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"NavigationController"];
        [self.revealViewController pushFrontViewController:vc animated:YES];
    }
}

- (IBAction)onClickClose:(id)sender {
    [self onClose];
}


- (IBAction)onClickSave:(id)sender {
    
    Preference* pref = [Preference getInstance];
    
    int row = (int)[pickerSelLang selectedRowInComponent:0];
    [pref putSharedPreference:nil :PREF_LANGUAGE WithINT:row];
    LocalizationSetLanguage(LANGUAGE_LOCALE[row]);
    
    [[NSUserDefaults standardUserDefaults] setObject:[NSArray arrayWithObjects:LANGUAGE_LOCALE[row], nil] forKey:@"AppleLanguages"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    if(btnLeftHandPalm.isSelected)
        [pref putSharedPreference:nil :PREF_HAND_LOCATION WithINT:0];
    else [pref putSharedPreference:nil :PREF_HAND_LOCATION WithINT:1];
    
    [self onClose];
}




/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 1;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    return 3;
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
    NSString * title = nil;
    if(pickerView == pickerSelLang) {
        switch(row) {
            case 0:
                title = LocalizedString(@"English");
                break;
            case 1:
                title = LocalizedString(@"Chinese(Simplified)");
                break;
            case 2:
                title = LocalizedString(@"Chinese(Traditional)");
                break;
        }
    }
    return title;
}


- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view{
    UILabel* tView = (UILabel*)view;
    if (!tView){
        tView = [[UILabel alloc] init];
        // Setup label properties - frame, font, colors etc
        [tView setFont:[UIFont systemFontOfSize:24]];
        tView.textAlignment = NSTextAlignmentCenter;
    }
    NSString * title = nil;

    switch(row) {
        case 0:
            title = LocalizedString(@"English");
            break;
        case 1:
            title = LocalizedString(@"Chinese(Simplified)");
            break;
        case 2:
            title = LocalizedString(@"Chinese(Traditional)");
            break;
    }
    [tView setText:title];
    // Fill the label text here
    return tView;
}
@end
