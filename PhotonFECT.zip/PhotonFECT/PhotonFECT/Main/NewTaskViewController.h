//
//  NewTaskViewController.h
//  PhotonFECT
//
//  Created by Suju on 7/2/19.
//  Copyright © 2019 Suju. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ItemModel.h"
@class BLEDeviceProperties;

@interface NewTaskViewController : UIViewController<UIAlertViewDelegate>
{    
    IBOutlet UILabel *lblTitle;
    IBOutlet UIView *uvConnectedStatus;
    
    IBOutlet UIImageView *ivBg;
    
    IBOutlet UIView *uvDirection1;
    IBOutlet UIView *uvDirection2;
    IBOutlet UIView *uvDirection3;
    IBOutlet UIView *uvDirection4;
    IBOutlet UIView *uvDirection5;
    IBOutlet UIView *uvDirection6;
    IBOutlet UIView *uvDirection7;
    IBOutlet UIView *uvDirection8;
    IBOutlet UILabel *lblTrigramTitle;
    
    UIView *uvDirections[8];
    UIColor *directionColors[6];
    
    IBOutlet UIButton *btNew;
    IBOutlet UIButton *btRun;    
    IBOutlet UIButton *btStop;
    
    IBOutlet UIButton *btFav;
    
}

@property (nonatomic, retain) ItemModel *itemModel;

@end
