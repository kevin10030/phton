//
//  NewTaskViewController.m
//  PhotonFECT
//
//  Created by Suju on 7/2/19.
//  Copyright © 2019 Suju. All rights reserved.
//

#import "NewTaskViewController.h"
#import "Utility.h"
#import "Constants.h"
#import "Preference.h"
#import "PhotonFECT-Swift.h"
#import "LocalizeHelper.h"
#import "DBManager.h"
#import "SWRevealViewController.h"

@interface NewTaskViewController ()<PropertiesDelegate>
{
    BLEDeviceProperties *bleCharProperties;
    int colorNums[8];
    CBPeripheral *currentPeripheral;
    CBService *currentService;
    CBCharacteristic *currentCharacteristic;
    
    ItemModel *favModel;
}
@end

@implementation NewTaskViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [lblTitle setText:LocalizedString(@"New Task")];
    [btNew setTitle:LocalizedString(@"New") forState:UIControlStateNormal];
    [btRun setTitle:LocalizedString(@"Run") forState:UIControlStateNormal];
    [btStop setTitle:LocalizedString(@"Stop") forState:UIControlStateNormal];
    
    bleCharProperties = [[BLEDeviceProperties alloc] init];
    bleCharProperties.delegate = self;
   
    currentPeripheral = [Utility getCurrentPeripheral];
    currentService = [Utility getCurrentService];
    currentCharacteristic = [Utility getCurrentCharacteristic];
    
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [self initStatus];
    [self rotateDirectionVews];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
}

-(void)initStatus
{
    Preference* pref = [Preference getInstance];
    if(self.itemModel != nil)
    {
        [pref putSharedPreference:nil :PREF_TASK_STATUS WithINT:JOB_STOPPED];
    }
    
    //Top bar
    int jobstatus = [pref getSharedPreference:nil :PREF_TASK_STATUS WithINT:JOB_NEW_TASK];
    [lblTitle setText:LocalizedString(TASK_TITLES[jobstatus])];
    
    if([pref getSharedPreference:nil :PREF_CONNECTION_STATUS WithBOOL:false])
    {
        uvConnectedStatus.backgroundColor = [UIColor greenColor];
    }else {
        uvConnectedStatus.backgroundColor = [UIColor redColor];
    }
    
    int direction =  [pref getSharedPreference:nil :PREF_HAND_LOCATION WithINT:0];
    if(direction == 0) {
        [ivBg setImage:[UIImage imageNamed:@"hand"]];
    } else {
        [ivBg setImage:[UIImage imageNamed:@"hand_right"]];
    }
    
    //bottom bar
    if(jobstatus == JOB_EXECUTING) {
        [lblTitle setText:LocalizedString(TASK_TITLES[JOB_EXECUTING])];
        btNew.enabled = false;
        btRun.enabled = false;
        btStop.enabled = true;
    }
    
    uvDirections[0] =uvDirection1;
    uvDirections[1] =uvDirection2;
    uvDirections[2] =uvDirection3;
    uvDirections[3] =uvDirection4;
    uvDirections[4] =uvDirection5;
    uvDirections[5] =uvDirection6;
    uvDirections[6] =uvDirection7;
    uvDirections[7] =uvDirection8;
    
    directionColors[0] = [UIColor colorWithRed:0 green:0 blue:0 alpha:1];
    directionColors[1] = [UIColor colorWithRed:255 green:255 blue:255 alpha:1];
    directionColors[2] = [UIColor colorWithRed:255 green:0 blue:0 alpha:1];
    directionColors[3] = [UIColor colorWithRed:0 green:255 blue:0 alpha:1];
    directionColors[4] = [UIColor colorWithRed:255 green:255 blue:0 alpha:1];
    directionColors[5] = [UIColor colorWithRed:255 green:255 blue:255 alpha:0];
    
    if(self.itemModel != nil)
    {
        NSString* color = self.itemModel.color;
        lblTrigramTitle.hidden = false;
        [lblTrigramTitle setText:self.itemModel.name];
        //C052101302
//        colorNums[5] = [[color substringWithRange:NSMakeRange(0, 1)] intValue];
//        colorNums[6] = [[color substringWithRange:NSMakeRange(1, 1)] intValue];
//        colorNums[7] = [[color substringWithRange:NSMakeRange(2, 1)] intValue];
//        colorNums[4] = [[color substringWithRange:NSMakeRange(3, 1)] intValue];
//        colorNums[0] = [[color substringWithRange:NSMakeRange(5, 1)] intValue];
//        colorNums[3] = [[color substringWithRange:NSMakeRange(6, 1)] intValue];
//        colorNums[2] = [[color substringWithRange:NSMakeRange(7, 1)] intValue];
//        colorNums[1] = [[color substringWithRange:NSMakeRange(8, 1)] intValue];
        
        [pref putSharedPreference:nil :PREF_DIRECTION_COLOR[5] WithINT:[[color substringWithRange:NSMakeRange(0, 1)] intValue]];
        [pref putSharedPreference:nil :PREF_DIRECTION_COLOR[6] WithINT:[[color substringWithRange:NSMakeRange(1, 1)] intValue]];
        [pref putSharedPreference:nil :PREF_DIRECTION_COLOR[7] WithINT:[[color substringWithRange:NSMakeRange(2, 1)] intValue]];
        [pref putSharedPreference:nil :PREF_DIRECTION_COLOR[4] WithINT:[[color substringWithRange:NSMakeRange(3, 1)] intValue]];
        [pref putSharedPreference:nil :PREF_DIRECTION_COLOR[0] WithINT:[[color substringWithRange:NSMakeRange(5, 1)] intValue]];
        [pref putSharedPreference:nil :PREF_DIRECTION_COLOR[3] WithINT:[[color substringWithRange:NSMakeRange(6, 1)] intValue]];
        [pref putSharedPreference:nil :PREF_DIRECTION_COLOR[2] WithINT:[[color substringWithRange:NSMakeRange(7, 1)] intValue]];
        [pref putSharedPreference:nil :PREF_DIRECTION_COLOR[1] WithINT:[[color substringWithRange:NSMakeRange(8, 1)] intValue]];
        
        favModel = [[DBManager getSharedInstance] findFavorite:self.itemModel];
        if(favModel == nil) {
            [btFav setImage:[UIImage imageNamed:@"fab_gray"] forState:UIControlStateNormal];
        } else {
            [btFav setImage:[UIImage imageNamed:@"fab"] forState:UIControlStateNormal];
        }
    } else {
        lblTrigramTitle.hidden = true;
    }
    
    //direction colors
    for(int i=0;i<8;i++)
    {
        int color = [pref getSharedPreference:nil :PREF_DIRECTION_COLOR[i] WithINT:5];
        uvDirections[i].backgroundColor = directionColors[color];
        
        uvDirections[i].layer.borderColor = [UIColor blackColor].CGColor;
        uvDirections[i].layer.borderWidth = 1.0f;
    }
}

-(void)rotateDirectionVews
{
//    CGRect screenRect = [[UIScreen mainScreen] bounds];
//    CGFloat screenWidth = screenRect.size.width;
//    CGFloat screenHeight = screenRect.size.height;
    
    //6,7,8
    //5,9,1
    //4,3,2
    int offset = 0;
    int direction =  [[Preference getInstance] getSharedPreference:nil :PREF_HAND_LOCATION WithINT:0];
    if(direction == 1) offset = -50;
    
    [uvDirection1 setTranslatesAutoresizingMaskIntoConstraints:NO];
    uvDirection1.frame = CGRectMake(uvDirection1.frame.origin.x+85+offset, uvDirection1.frame.origin.y,uvDirection1.frame.size.width,uvDirection1.frame.size.height);
    CGFloat degrees = 0; //the value in degrees
    CGFloat radians_ = atan2f(uvDirection1.transform.b, uvDirection1.transform.a);
    CGFloat degrees_ = radians_ * (180 / M_PI);
    CGAffineTransform transform = CGAffineTransformMakeRotation((degrees + degrees_) * M_PI/180);
    uvDirection1.transform = transform;
    //uvDirection1.transform = CGAffineTransformMakeRotation(degrees*M_PI/180);

    uvDirection2.frame = CGRectMake(uvDirection2.frame.origin.x+60+offset, uvDirection2.frame.origin.y+60,uvDirection2.frame.size.width,uvDirection2.frame.size.height);
    [uvDirection2 setTranslatesAutoresizingMaskIntoConstraints:NO];
    degrees = 45; //the value in degrees
    //uvDirection2.transform = CGAffineTransformMakeRotation(degrees*M_PI/180);
    radians_ = atan2f(uvDirection2.transform.b, uvDirection2.transform.a);
    degrees_ = radians_ * (180 / M_PI);
    transform = CGAffineTransformMakeRotation((degrees + degrees_) * M_PI/180);
    uvDirection2.transform = transform;
    
    uvDirection3.frame = CGRectMake(uvDirection3.frame.origin.x+offset, uvDirection3.frame.origin.y+85,uvDirection3.frame.size.width,uvDirection3.frame.size.height);
    [uvDirection3 setTranslatesAutoresizingMaskIntoConstraints:NO];
    degrees = 90; //the value in degrees
    //uvDirection3.transform = CGAffineTransformMakeRotation(degrees*M_PI/180);
    radians_ = atan2f(uvDirection3.transform.b, uvDirection3.transform.a);
    degrees_ = radians_ * (180 / M_PI);
    transform = CGAffineTransformMakeRotation((degrees + degrees_) * M_PI/180);
    uvDirection3.transform = transform;
    
    uvDirection4.frame = CGRectMake(uvDirection4.frame.origin.x-60+offset, uvDirection4.frame.origin.y+60,uvDirection4.frame.size.width,uvDirection4.frame.size.height);
    [uvDirection4 setTranslatesAutoresizingMaskIntoConstraints:NO];
    degrees = 135; //the value in degrees
    //uvDirection4.transform = CGAffineTransformMakeRotation(degrees*M_PI/180);
    radians_ = atan2f(uvDirection4.transform.b, uvDirection4.transform.a);
    degrees_ = radians_ * (180 / M_PI);
    transform = CGAffineTransformMakeRotation((degrees + degrees_) * M_PI/180);
    uvDirection4.transform = transform;
    
    uvDirection5.frame = CGRectMake(uvDirection5.frame.origin.x-85+offset, uvDirection5.frame.origin.y,uvDirection5.frame.size.width,uvDirection5.frame.size.height);
    [uvDirection5 setTranslatesAutoresizingMaskIntoConstraints:NO];
    degrees = 180; //the value in degrees
    //uvDirection5.transform = CGAffineTransformMakeRotation(degrees*M_PI/180);
    radians_ = atan2f(uvDirection5.transform.b, uvDirection5.transform.a);
    degrees_ = radians_ * (180 / M_PI);
    transform = CGAffineTransformMakeRotation((degrees + degrees_) * M_PI/180);
    uvDirection5.transform = transform;
    
    uvDirection6.frame = CGRectMake(uvDirection6.frame.origin.x-60+offset, uvDirection6.frame.origin.y-60,uvDirection6.frame.size.width,uvDirection6.frame.size.height);
    [uvDirection6 setTranslatesAutoresizingMaskIntoConstraints:NO];
    degrees = 225; //the value in degrees
    //uvDirection6.transform = CGAffineTransformMakeRotation(degrees*M_PI/180);
    radians_ = atan2f(uvDirection6.transform.b, uvDirection6.transform.a);
    degrees_ = radians_ * (180 / M_PI);
    transform = CGAffineTransformMakeRotation((degrees + degrees_) * M_PI/180);
    uvDirection6.transform = transform;

    uvDirection7.frame = CGRectMake(uvDirection7.frame.origin.x+offset, uvDirection7.frame.origin.y-85,uvDirection7.frame.size.width,uvDirection7.frame.size.height);
    [uvDirection7 setTranslatesAutoresizingMaskIntoConstraints:NO];
    degrees = 270; //the value in degrees
    //uvDirection7.transform = CGAffineTransformMakeRotation(degrees*M_PI/180);
    radians_ = atan2f(uvDirection7.transform.b, uvDirection7.transform.a);
    degrees_ = radians_ * (180 / M_PI);
    transform = CGAffineTransformMakeRotation((degrees + degrees_) * M_PI/180);
    uvDirection7.transform = transform;
    
    uvDirection8.frame = CGRectMake(uvDirection8.frame.origin.x+60+offset, uvDirection8.frame.origin.y-60,uvDirection8.frame.size.width,uvDirection8.frame.size.height);
    [uvDirection8 setTranslatesAutoresizingMaskIntoConstraints:NO];
    degrees = 315; //the value in degrees
    //uvDirection8.transform = CGAffineTransformMakeRotation(degrees*M_PI/180);
//    radians_ = atan2f(uvDirection8.transform.b, uvDirection8.transform.a);
//    degrees_ = radians_ * (180 / M_PI);
//    transform = CGAffineTransformMakeRotation((degrees + degrees_) * M_PI/180);
//    uvDirection8.transform = transform;
    uvDirection8.transform = CGAffineTransformRotate(uvDirection8.transform, 1.75*M_PI);

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)onClickClose:(id)sender {
    if (self.revealViewController != NULL) {
        UIViewController *vc = [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"NavigationController"];
        [self.revealViewController pushFrontViewController:vc animated:YES];
    } else {
        [self dismissViewControllerAnimated:YES completion:^{
            
        }];
    }
     
 }

- (IBAction)onClickDirection:(id)sender {
    UIButton *button = (UIButton *)sender;
    
    NSLog(@"tag:%ld",(long)button.tag);
    
    UIAlertController *actionSheet = [UIAlertController alertControllerWithTitle:LocalizedString(@"Choose Color") message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    
    [actionSheet addAction:[UIAlertAction actionWithTitle:LocalizedString(@"Cancel") style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {
        // Cancel button tappped do nothing.
    }]];
    
    //BLACK,WHITE,RED,GREE,YELLO,EMPTY
   [actionSheet addAction:[UIAlertAction actionWithTitle:LocalizedString(@"BLACK") style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        @try {[[Preference getInstance] putSharedPreference:nil :PREF_DIRECTION_COLOR[button.tag-1] WithINT:0];} @catch (NSException *exception) {}
       self->uvDirections[button.tag-1].backgroundColor = self->directionColors[0];
    }]];
    [actionSheet addAction:[UIAlertAction actionWithTitle:LocalizedString(@"WHITE") style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        @try {[[Preference getInstance] putSharedPreference:nil :PREF_DIRECTION_COLOR[button.tag-1] WithINT:1];} @catch (NSException *exception) {}
        self->uvDirections[button.tag-1].backgroundColor = self->directionColors[1];
    }]];
    [actionSheet addAction:[UIAlertAction actionWithTitle:LocalizedString(@"RED") style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        @try {[[Preference getInstance] putSharedPreference:nil :PREF_DIRECTION_COLOR[button.tag-1] WithINT:2];} @catch (NSException *exception) {}
        self->uvDirections[button.tag-1].backgroundColor = self->directionColors[2];
    }]];
    [actionSheet addAction:[UIAlertAction actionWithTitle:LocalizedString(@"GREEN") style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        @try {[[Preference getInstance] putSharedPreference:nil :PREF_DIRECTION_COLOR[button.tag-1] WithINT:3];} @catch (NSException *exception) {}
        self->uvDirections[button.tag-1].backgroundColor = self->directionColors[3];
    }]];
    [actionSheet addAction:[UIAlertAction actionWithTitle:LocalizedString(@"YELLOW") style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        @try {[[Preference getInstance] putSharedPreference:nil :PREF_DIRECTION_COLOR[button.tag-1] WithINT:4];} @catch (NSException *exception) {}
        self->uvDirections[button.tag-1].backgroundColor = self->directionColors[4];
    }]];
    [actionSheet addAction:[UIAlertAction actionWithTitle:LocalizedString(@"EMPTY") style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        @try {[[Preference getInstance] putSharedPreference:nil :PREF_DIRECTION_COLOR[button.tag-1] WithINT:5];} @catch (NSException *exception) {}
        self->uvDirections[button.tag-1].backgroundColor = self->directionColors[5];
    }]];
    
    [self presentViewController:actionSheet animated:YES completion:nil];
}

- (IBAction)onClickNew:(id)sender {
    [lblTitle setText:LocalizedString(TASK_TITLES[JOB_NEW_TASK])];
    
    //direction colors empty
    for(int i=0;i<8;i++) {
        @try {[[Preference getInstance] putSharedPreference:nil :PREF_DIRECTION_COLOR[i] WithINT:5];} @catch (NSException *exception) {}
        uvDirections[i].backgroundColor = directionColors[5];
    }
    
    //NEW TASK status
    @try {[[Preference getInstance] putSharedPreference:nil :PREF_TASK_STATUS WithINT:JOB_NEW_TASK];} @catch (NSException *exception) {}
}

- (IBAction)onClickRun:(id)sender {
//    UIAlertView *alertView = [[UIAlertView alloc]
//                              initWithTitle:LocalizedString(@"Are you sure to run?")
//                              message:nil
//                              delegate:self
//                              cancelButtonTitle:nil
//                              otherButtonTitles:LocalizedString(@"Yes"),LocalizedString(@"No"), nil];
//    alertView.tag = JOB_EXECUTING;
//    [alertView show];
    
    
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:LocalizedString(@"Are you sure to run?")
                       message:nil
                preferredStyle:UIAlertControllerStyleAlert];

    UIAlertAction *submit = [UIAlertAction actionWithTitle:LocalizedString(@"Yes") style:UIAlertActionStyleDefault
                                                   handler:^(UIAlertAction * action) {
                                                       [self jobExecuting];
                                                   }];
    
    UIAlertAction *cancel = [UIAlertAction actionWithTitle:LocalizedString(@"No") style:UIAlertActionStyleCancel handler:nil];
    
    [alert addAction:submit];
    [alert addAction:cancel];
    [self presentViewController:alert animated:YES completion:nil];
    
}

-(void) jobExecuting
{
    Preference* pref = [Preference getInstance];
    if([pref getSharedPreference:nil :PREF_CONNECTION_STATUS WithBOOL:false])
    {
        ///////
        //6,7,8
        //5,9,1
        //4,3,2
        if(currentCharacteristic == nil) {
            [[Utility getInstance] showToastMessage:LocalizedString(@"Please select characteristic")];
        } else {
            @try{
                for(int i=0;i<8;i++)
                {
                    colorNums[i] = [pref getSharedPreference:nil :PREF_DIRECTION_COLOR[i] WithINT:5];
                }
                //C052101302
                Preference* pref = [Preference getInstance];
                int direction =  [pref getSharedPreference:nil :PREF_HAND_LOCATION WithINT:0];
                NSString *command = [NSString stringWithFormat:@"%@%d%d%d%d0%d%d%d%d",COMMAND_SENT_COLOR,colorNums[5],colorNums[6],colorNums[7],colorNums[4],colorNums[0],colorNums[3],colorNums[2],colorNums[1]];
                if(direction == 1)
                    command = [NSString stringWithFormat:@"%@%d%d%d%d0%d%d%d%d",COMMAND_SENT_COLOR,colorNums[7],colorNums[6],colorNums[5],colorNums[0],colorNums[4],colorNums[1],colorNums[2],colorNums[3]];
                
                NSData *data = [command dataUsingEncoding:NSUTF8StringEncoding allowLossyConversion:NO];
                //NSData * data = [NSData dataWithBytes:command.UTF8String length:sizeof(command)];
                [bleCharProperties writeCharacteristicValueWithPeripheral:currentPeripheral data:data char:currentCharacteristic type:CBCharacteristicWriteWithResponse];
                
                [lblTitle setText:LocalizedString(TASK_TITLES[JOB_EXECUTING])];
                btNew.enabled = false;
                btRun.enabled = false;
                btStop.enabled = true;
                @try {[pref putSharedPreference:nil :PREF_TASK_STATUS WithINT:JOB_EXECUTING];} @catch (NSException *exception) {}
                // [[Utility getInstance] showToastMessage:command];
            }@catch(NSException *exception){}
        }
        //[bleCharProperties readCharacteristicValueWithPeripheral:currentPeripheral char:currentCharacteristic];
    } else {
        [[Utility getInstance] showToastMessage:LocalizedString(@"Please connect to 5CH device First!")];
    }
}

-(void) jobStopping
{
    Preference* pref = [Preference getInstance];
    if([pref getSharedPreference:nil :PREF_CONNECTION_STATUS WithBOOL:false])
    {
        if(currentCharacteristic == nil) {
            [[Utility getInstance] showToastMessage:LocalizedString(@"Please select characteristic")];
        } else {
            @try{
                NSData *data = [COMMAND_STOP dataUsingEncoding:NSUTF8StringEncoding allowLossyConversion:NO];
                //NSData * data = [NSData dataWithBytes:COMMAND_STOP.UTF8String length:sizeof(COMMAND_STOP)];
                [bleCharProperties writeCharacteristicValueWithPeripheral:currentPeripheral data:data char:currentCharacteristic type:CBCharacteristicWriteWithResponse];
                //once stop Yes, top bar is "Stopping...", progress dialog, and then "Job Stopped", and then bottom bar is "New, Run"
                [lblTitle setText:LocalizedString(TASK_TITLES[JOB_STOPPING])];
                [lblTitle setText:LocalizedString(TASK_TITLES[JOB_STOPPED])];
                btNew.enabled = true;
                btRun.enabled = true;
                btStop.enabled = false;
                @try {[[Preference getInstance] putSharedPreference:nil :PREF_TASK_STATUS WithINT:JOB_STOPPED];} @catch (NSException *exception) {}
            }@catch(NSException *exception){}
        }
    } else {
        [[Utility getInstance] showToastMessage:LocalizedString(@"Please connect to 5CH device First!")];
    }
}

- (IBAction)onClickStop:(id)sender {
//    UIAlertView *alertView = [[UIAlertView alloc]
//                              initWithTitle:LocalizedString(@"Are you sure to stop?")
//                              message:nil
//                              delegate:self
//                              cancelButtonTitle:nil
//                              otherButtonTitles:LocalizedString(@"Yes"),LocalizedString(@"No"), nil];
//    alertView.tag = JOB_STOPPING;
//    [alertView show];
    
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:LocalizedString(@"Are you sure to stop?")
                                                                   message:nil
                                                            preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *submit = [UIAlertAction actionWithTitle:LocalizedString(@"Yes") style:UIAlertActionStyleDefault
                                                   handler:^(UIAlertAction * action) {
                                                       [self jobStopping];
                                                   }];
    
    UIAlertAction *cancel = [UIAlertAction actionWithTitle:LocalizedString(@"No") style:UIAlertActionStyleCancel handler:nil];
    
    [alert addAction:submit];
    [alert addAction:cancel];
    [self presentViewController:alert animated:YES completion:nil];
}

- (IBAction)onClickFavorite:(id)sender {
    if(self.itemModel == nil) {
        if(favModel == nil) {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:LocalizedString(@"Favorite")
                                                                       message:LocalizedString(@"Enter color scheme name below")
                                                                preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction *submit = [UIAlertAction actionWithTitle:LocalizedString(@"Save") style:UIAlertActionStyleDefault
                                                       handler:^(UIAlertAction * action) {
                                                           
                                                           if (alert.textFields.count > 0) {
                                                               UITextField *textField = [alert.textFields firstObject];
                                                               if(textField.text.length > 0)
                                                                   [self saveFavorite:textField.text];
                                                           }
                                                           
                                                       }];
       
        UIAlertAction *cancel = [UIAlertAction actionWithTitle:LocalizedString(@"Cancel") style:UIAlertActionStyleCancel handler:nil];
        
        [alert addAction:submit];
        [alert addAction:cancel];
        
        [alert addTextFieldWithConfigurationHandler:^(UITextField *textField) {
            textField.placeholder = LocalizedString(@"Color Scheme Name"); // if needs
        }];
        
        [self presentViewController:alert animated:YES completion:nil];
        } else {
            [[DBManager getSharedInstance] removeFavorite:favModel];
            [btFav setImage:[UIImage imageNamed:@"fab_gray"] forState:UIControlStateNormal];
            favModel = nil;
        }
    } else {
        if(favModel == nil) {
            [self saveFavorite:self.itemModel.name];
        } else {
            [[DBManager getSharedInstance] removeFavorite:favModel];
            [btFav setImage:[UIImage imageNamed:@"fab_gray"] forState:UIControlStateNormal];
            favModel = nil;
        }
    }
}

-(void)saveFavorite:(NSString *)name
{
    ItemModel *model = [[ItemModel alloc] init];
    model.name = name;
    Preference* pref = [Preference getInstance];
    for(int i=0;i<8;i++)
    {
        colorNums[i] = [pref getSharedPreference:nil :PREF_DIRECTION_COLOR[i] WithINT:5];
    }
    model.color = [NSString stringWithFormat:@"%d%d%d%d0%d%d%d%d",colorNums[5],colorNums[6],colorNums[7],colorNums[4],colorNums[0],colorNums[3],colorNums[2],colorNums[1]];
    
    model.ID = [[DBManager getSharedInstance] saveFavorite:model];
    
    if(model.ID == 0) {
        [btFav setImage:[UIImage imageNamed:@"fab_gray"] forState:UIControlStateNormal];
    } else {
        [btFav setImage:[UIImage imageNamed:@"fab"] forState:UIControlStateNormal];
    }
    favModel = model;
    [[Utility getInstance] showToastMessage:LocalizedString(@"Save")];
    
}


//#pragma -mark AlertDialog
//- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex {
//    if (buttonIndex == 0) {
//        Preference* pref = [Preference getInstance];
//        if(alertView.tag == JOB_EXECUTING)
//        {
//            if([pref getSharedPreference:nil :PREF_CONNECTION_STATUS WithBOOL:false])
//            {
//                ///////
//                //6,7,8
//                //5,9,1
//                //4,3,2
//                if(currentCharacteristic == nil) {
//                    [[Utility getInstance] showToastMessage:LocalizedString(@"Please select characteristic")];
//                } else {
//                    @try{
//                        for(int i=0;i<8;i++)
//                        {
//                            colorNums[i] = [pref getSharedPreference:nil :PREF_DIRECTION_COLOR[i] WithINT:5];
//                        }
//                        //C052101302
//                        Preference* pref = [Preference getInstance];
//                        int direction =  [pref getSharedPreference:nil :PREF_HAND_LOCATION WithINT:0];
//                        NSString *command = [NSString stringWithFormat:@"%@%d%d%d%d0%d%d%d%d",COMMAND_SENT_COLOR,colorNums[5],colorNums[6],colorNums[7],colorNums[4],colorNums[0],colorNums[3],colorNums[2],colorNums[1]];
//                        if(direction == 1)
//                            command = [NSString stringWithFormat:@"%@%d%d%d%d0%d%d%d%d",COMMAND_SENT_COLOR,colorNums[7],colorNums[6],colorNums[5],colorNums[0],colorNums[4],colorNums[1],colorNums[2],colorNums[3]];
//
//                        NSData *data = [command dataUsingEncoding:NSUTF8StringEncoding allowLossyConversion:NO];
//                        //NSData * data = [NSData dataWithBytes:command.UTF8String length:sizeof(command)];
//                        [bleCharProperties writeCharacteristicValueWithPeripheral:currentPeripheral data:data char:currentCharacteristic type:CBCharacteristicWriteWithResponse];
//
//                        [lblTitle setText:LocalizedString(TASK_TITLES[JOB_EXECUTING])];
//                        btNew.enabled = false;
//                        btRun.enabled = false;
//                        btStop.enabled = true;
//                        @try {[pref putSharedPreference:nil :PREF_TASK_STATUS WithINT:JOB_EXECUTING];} @catch (NSException *exception) {}
//                       // [[Utility getInstance] showToastMessage:command];
//                    }@catch(NSException *exception){}
//                }
//                //[bleCharProperties readCharacteristicValueWithPeripheral:currentPeripheral char:currentCharacteristic];
//            } else {
//                [[Utility getInstance] showToastMessage:LocalizedString(@"Please connect to 5CH device First!")];
//            }
//        } else if(alertView.tag == JOB_STOPPING) {
//            if([pref getSharedPreference:nil :PREF_CONNECTION_STATUS WithBOOL:false])
//            {
//                if(currentCharacteristic == nil) {
//                    [[Utility getInstance] showToastMessage:LocalizedString(@"Please select characteristic")];
//                } else {
//                    @try{
//                    NSData *data = [COMMAND_STOP dataUsingEncoding:NSUTF8StringEncoding allowLossyConversion:NO];
//                    //NSData * data = [NSData dataWithBytes:COMMAND_STOP.UTF8String length:sizeof(COMMAND_STOP)];
//                    [bleCharProperties writeCharacteristicValueWithPeripheral:currentPeripheral data:data char:currentCharacteristic type:CBCharacteristicWriteWithResponse];
//                        //once stop Yes, top bar is "Stopping...", progress dialog, and then "Job Stopped", and then bottom bar is "New, Run"
//                        [lblTitle setText:LocalizedString(TASK_TITLES[JOB_STOPPING])];
//                        [lblTitle setText:LocalizedString(TASK_TITLES[JOB_STOPPED])];
//                        btNew.enabled = true;
//                        btRun.enabled = true;
//                        btStop.enabled = false;
//                        @try {[[Preference getInstance] putSharedPreference:nil :PREF_TASK_STATUS WithINT:JOB_STOPPED];} @catch (NSException *exception) {}
//                    }@catch(NSException *exception){}
//                }
//            } else {
//                [[Utility getInstance] showToastMessage:LocalizedString(@"Please connect to 5CH device First!")];
//            }
//        }
//    }
//}

//PropertiesDelegate
-(void)postWriteCharacteristicValueWithPeripheral:(CBPeripheral *)peripheral char:(CBCharacteristic *)char_
{
 
}

-(void)postWriteCharacteristicValueFailedWithError:(NSError *)error
{
    @try{
        [[Utility getInstance] showToastMessage:[NSString stringWithFormat:@"WriteError - %@", [error localizedDescription]]];
    }@catch (NSException *exception) {}
}

-(void)postReadCharacteristicValueWithPeripheral:(CBPeripheral *)peripheral char:(CBCharacteristic *)char_
{
    //NSData *data = char_.value;
    //NSString *readStr = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
   // [[Utility getInstance] showToastMessage:readStr];
}

-(void)postReadCharacteristicValueFailedWithError:(NSError *)error
{
   /* @try{
        [[Utility getInstance] showToastMessage:[NSString stringWithFormat:@"%@ReadError - %@", [error localizedDescription]]];
    }@catch (NSException *exception) {}
    */
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
