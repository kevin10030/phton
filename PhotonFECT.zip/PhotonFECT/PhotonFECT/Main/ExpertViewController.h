//
//  ExpertViewController.h
//  PhotonFECT
//
//  Created by Suju on 8/1/19.
//  Copyright © 2019 Suju. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GroupModel.h"

@interface ExpertViewController : UIViewController<UITableViewDelegate,UITableViewDataSource>
{
    
    IBOutlet UILabel *lbTitle;
    IBOutlet UITableView *tvExpert;
}

@property (nonatomic, retain) GroupModel *gropModel;
@end
