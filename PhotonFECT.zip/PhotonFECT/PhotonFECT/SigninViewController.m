//
//  LoginViewController.m
//  com.homing.eng.alwayshome
//
//  Created by zhaochenghe on 4/1/17.
//  Copyright © 2017 jn. All rights reserved.
//

#import "SigninViewController.h"
#import "Utility.h"
#import "LocalizeHelper.h"
#import "Preference.h"
#import "Constants.h"

@interface SigninViewController ()

@end

@implementation SigninViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [tfEmail setPlaceholder:LocalizedString(@"Email")];
    [tfPassword setPlaceholder:LocalizedString(@"Password")];
    [btnSignIn setTitle:LocalizedString(@"SIGN IN") forState:UIControlStateNormal];
    [btnSignUp setTitle:LocalizedString(@"NOT A MEMBER? SIGN UP") forState:UIControlStateNormal];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewDidAppear:(BOOL) animated {
    [super viewDidAppear:animated];
}

- (IBAction)onClickLogin:(id)sender {
    
//    if(![Utility IsValidEmail:tfEmail.text] ) {
//        [[Utility getInstance] showToastMessage:LocalizedString(@"Please input correct email.")];
//        return;
//    }
//    if([tfPassword.text isEqualToString:@""]) {
//        [[Utility getInstance] showToastMessage:LocalizedString(@"Please input your password.")];
//        return;
//    }
//    
//    Preference* pref = [Preference getInstance];
//    [pref putSharedPreference:nil :PREF_USER_EMAIL :tfEmail.text];
    
     [[Utility getInstance] gotoScreen:self :@"MainViewController"];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

#pragma mark -
#pragma mark UITouch Methods

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    
    [[Utility getInstance] cmdHideKeyboard:txtfControl];
    
}

#pragma mark -
#pragma mark UITextFieldDelegate Methods

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    
    txtfControl = textField;
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [[Utility getInstance] cmdHideKeyboard:textField];
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    
//    NSString *str = [[textField text] stringByReplacingCharactersInRange:range withString:string];
    
    
    return true;
}

@end
