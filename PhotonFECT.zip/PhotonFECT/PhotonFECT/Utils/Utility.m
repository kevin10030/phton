//
//  Utility.m
//  PhotonFECT
//

#import "MainViewController.h"
#import "DrawerViewController.h"
#import "MMDrawerController.h"
#import "MMDrawerVisualState.h"
#import "Utility.h"
#import "MBProgressHUD.h"
#import "AppDelegate.h"


MBProgressHUD  *gHUD = nil;
BOOL gIsShowHUD = NO;
int  gHUDRequesCount = 0;
CBPeripheral *g_peripheral = nil;
CBService *g_service = nil;
CBCharacteristic *g_characteristic = nil;

@implementation Utility
static Utility *singletone = nil;

+ (Utility *)getInstance
{
    if (singletone == nil)
        singletone = [[Utility alloc] init];
    
    return singletone;
}

+ (void) setCurrentPeripheral:(CBPeripheral *)peripheral
{
    g_peripheral = peripheral;
}

+ (CBPeripheral *) getCurrentPeripheral
{
    return g_peripheral;
}

+ (void) setCurrentService:(CBService *)service
{
    g_service = service;
}

+ (CBService *) getCurrentService
{
    return g_service;
}

+ (void) setCurrentCharacteristic:(CBCharacteristic *)characteristic
{
    g_characteristic = characteristic;
}

+ (CBCharacteristic *) getCurrentCharacteristic
{
    return g_characteristic;
}

- (void)cmdHideKeyboard:(UITextField*)_txtField {
    
    if (_txtField != nil && [_txtField isFirstResponder]) {
        [_txtField resignFirstResponder];
    }
    
}

-(NSString *)getDateTime:(NSString *)str
{
    str = [str stringByReplacingOccurrencesOfString:@"T" withString:@" "];
    str = [str stringByReplacingOccurrencesOfString:@"Z" withString:@" "];
    return str;
}

+(BOOL) IsValidEmail:(NSString *)checkString
{
    BOOL stricterFilter = NO; // Discussion http://blog.logichigh.com/2010/09/02/validating-an-e-mail-address/
    NSString *stricterFilterString = @"^[A-Z0-9a-z\\._%+-]+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2,4}$";
    NSString *laxString = @"^.+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2}[A-Za-z]*$";
    NSString *emailRegex = stricterFilter ? stricterFilterString : laxString;
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:checkString];
}

-(void)showToastMessage:(NSString *)message
{
    AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];

    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:appDelegate.window
                                              animated:YES];
    if (!isiPhone) {
        hud.detailsLabel.font=[UIFont systemFontOfSize:25.0];
    }
    // Configure for text only and offset down
    hud.mode = MBProgressHUDModeText;
    hud.detailsLabel.text = message;
    hud.margin = 10.f;
    
    CGRect screenRect = [[UIScreen mainScreen] bounds];
    CGFloat screenHeight = screenRect.size.height;
    hud.offset = CGPointMake(0.f, screenHeight/2-100.0f);

    
    hud.removeFromSuperViewOnHide = YES;
    [hud hideAnimated:YES afterDelay:3.0];
}

+ (void) showProgressDialog:(UIViewController*)controller {
    if(YES == gIsShowHUD) {
        gHUDRequesCount++;
        return;
    }
    
    if(true) {
       // UIWindow* w_pMainWindow = [[UIApplication sharedApplication].windows objectAtIndex:0];
        
        //gHUD = [MBProgressHUD showHUDAddedTo:w_pMainWindow animated:YES];
        gHUD = [MBProgressHUD showHUDAddedTo:controller.view animated:YES];
        gHUD.mode = MBProgressHUDModeIndeterminate;
        gHUD.label.text = @"Loading......";
        //        gHUD.labelText = @"";
        [gHUD showAnimated:NO];
    }
    
    gIsShowHUD = YES;
}

+ (void) hideProgressDialog {
    
    if(gHUDRequesCount != 0) {
        gHUDRequesCount--;
    }
    else if(gIsShowHUD == YES) {
        
        if(true) {
            [gHUD hideAnimated:NO];
        }
        
        gIsShowHUD = NO;
        gHUDRequesCount = 0;
    }
}

- (UIImage*)circularScaleNCrop:(UIImage*)images  with :(CGRect) rect
{
    //Create the bitmap graphics context
    UIGraphicsBeginImageContextWithOptions(CGSizeMake(rect.size.width, rect.size.height), NO, 0.0);
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    //Get the width and heights
    CGFloat imageWidth = images.size.width;
    CGFloat imageHeight = images.size.height;
    CGFloat rectWidth = rect.size.width;
    CGFloat rectHeight = rect.size.height;
    
    //Calculate the scale factor
    CGFloat scaleFactorX = rectWidth/imageWidth;
    CGFloat scaleFactorY = rectHeight/imageHeight;
    
    //Calculate the centre of the circle
    CGFloat imageCentreX = rectWidth/2;
    CGFloat imageCentreY = rectHeight/2;
    
    // Create and CLIP to a CIRCULAR Path
    // (This could be replaced with any closed path if you want a different shaped clip)
    CGFloat radius = rectWidth/2;
    CGContextBeginPath (context);
    CGContextAddArc (context, imageCentreX, imageCentreY, radius, 0, 2*M_PI, 0);
    CGContextClosePath (context);
    CGContextClip (context);
    
    CGContextScaleCTM (context, scaleFactorX, scaleFactorY);
    
    // Draw the IMAGE
    CGRect myRect = CGRectMake(0, 0, imageWidth, imageHeight);
    [images drawInRect:myRect];
    
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return newImage;
}

- (UIImage *)scaleAndRotateImage:(UIImage *)image
{
    int kMaxResolution = 320; // Or whatever
    
    CGImageRef imgRef = image.CGImage;
    
    CGFloat width = CGImageGetWidth(imgRef);
    CGFloat height = CGImageGetHeight(imgRef);
    
    CGAffineTransform transform = CGAffineTransformIdentity;
    CGRect bounds = CGRectMake(0, 0, width, height);
    if (width > kMaxResolution || height > kMaxResolution) {
        CGFloat ratio = width/height;
        if (ratio > 1) {
            bounds.size.width = kMaxResolution;
            bounds.size.height = roundf(bounds.size.width / ratio);
        }
        else {
            bounds.size.height = kMaxResolution;
            bounds.size.width = roundf(bounds.size.height * ratio);
        }
    }
    
    CGFloat scaleRatio = bounds.size.width / width;
    CGSize imageSize = CGSizeMake(CGImageGetWidth(imgRef), CGImageGetHeight(imgRef));
    CGFloat boundHeight;
    UIImageOrientation orient = image.imageOrientation;
    switch(orient) {
            
        case UIImageOrientationUp: //EXIF = 1
            
            // landscape right
            transform = CGAffineTransformIdentity;
            break;
            
        case UIImageOrientationUpMirrored: //EXIF = 2
            transform = CGAffineTransformMakeTranslation(imageSize.width, 0.0);
            transform = CGAffineTransformScale(transform, -1.0, 1.0);
            break;
            
        case UIImageOrientationDown: //EXIF = 3
            
            // landscape left
            transform = CGAffineTransformMakeTranslation(imageSize.width, imageSize.height);
            transform = CGAffineTransformRotate(transform, M_PI);
            break;
            
        case UIImageOrientationDownMirrored: //EXIF = 4
            transform = CGAffineTransformMakeTranslation(0.0, imageSize.height);
            transform = CGAffineTransformScale(transform, 1.0, -1.0);
            break;
            
        case UIImageOrientationLeftMirrored: //EXIF = 5
            boundHeight = bounds.size.height;
            bounds.size.height = bounds.size.width;
            bounds.size.width = boundHeight;
            transform = CGAffineTransformMakeTranslation(imageSize.height, imageSize.width);
            transform = CGAffineTransformScale(transform, -1.0, 1.0);
            transform = CGAffineTransformRotate(transform, 3.0 * M_PI / 2.0);
            break;
            
        case UIImageOrientationLeft: //EXIF = 6
            boundHeight = bounds.size.height;
            bounds.size.height = bounds.size.width;
            bounds.size.width = boundHeight;
            transform = CGAffineTransformMakeTranslation(0.0, imageSize.width);
            transform = CGAffineTransformRotate(transform, 3.0 * M_PI / 2.0);
            break;
            
        case UIImageOrientationRightMirrored: //EXIF = 7
            boundHeight = bounds.size.height;
            bounds.size.height = bounds.size.width;
            bounds.size.width = boundHeight;
            transform = CGAffineTransformMakeScale(-1.0, 1.0);
            transform = CGAffineTransformRotate(transform, M_PI / 2.0);
            break;
            
        case UIImageOrientationRight: //EXIF = 8
            
            // Portrait Mode
            boundHeight = bounds.size.height;
            bounds.size.height = bounds.size.width;
            bounds.size.width = boundHeight;
            transform = CGAffineTransformMakeTranslation(imageSize.height, 0.0);
            transform = CGAffineTransformRotate(transform, M_PI / 2.0);
            break;
            
        default:
            [NSException raise:NSInternalInconsistencyException format:@"Invalid image orientation"];
    }
    
    UIGraphicsBeginImageContext(bounds.size);
    
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    if (orient == UIImageOrientationRight || orient == UIImageOrientationLeft) {
        CGContextScaleCTM(context, -scaleRatio, scaleRatio);
        CGContextTranslateCTM(context, -height, 0);
    }
    else {
        CGContextScaleCTM(context, scaleRatio, -scaleRatio);
        CGContextTranslateCTM(context, 0, -height);
    }
    
    CGContextConcatCTM(context, transform);
    
    CGContextDrawImage(UIGraphicsGetCurrentContext(), CGRectMake(0, 0, width, height), imgRef);
    UIImage *imageCopy = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return imageCopy;
}

-(void)gotoScreen:(UIViewController *)curController :(NSString*)storyboardID
{
    CATransition* transition = [CATransition animation];
    transition.duration = 0.3;
    transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseOut];
    transition.type = kCATransitionPush;
    transition.subtype = kCATransitionFromRight;
    
    AppDelegate* appDelegate;
    appDelegate = (AppDelegate*)[[UIApplication sharedApplication]delegate];
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    if(curController == nil) curController = [appDelegate.window rootViewController];
    if([storyboardID isEqualToString:@"MainViewController"])
    {
        CGRect screenRect = [[UIScreen mainScreen] bounds];
        //CGFloat screenWidth = screenRect.size.width;
        CGFloat screenHeight = screenRect.size.height;
        
        // 3. Create vc
        
        UINavigationController *navViewController = [storyboard instantiateViewControllerWithIdentifier:@"NavigationController"];
        
        //MainViewController *mainViewController = [storyboard instantiateViewControllerWithIdentifier:NSStringFromClass([MainViewController class])];
        DrawerViewController *drawerViewController = [storyboard instantiateViewControllerWithIdentifier:NSStringFromClass([DrawerViewController class])];
        
        [drawerViewController.view setFrame:CGRectMake(0, 0, 240, screenHeight)];
        
        MMDrawerController * drawerController = [[MMDrawerController alloc]
                                 initWithCenterViewController:navViewController
                                 leftDrawerViewController:drawerViewController];
        
        [drawerController setShowsShadow:NO];
        [drawerController setRestorationIdentifier:@"MMDrawer"];
        [drawerController setMaximumLeftDrawerWidth:240];
        [drawerController setOpenDrawerGestureModeMask:MMOpenDrawerGestureModeAll];
        [drawerController setCloseDrawerGestureModeMask:MMCloseDrawerGestureModeAll];

        [curController.view.window.layer addAnimation:transition forKey:nil];
        [appDelegate.window setRootViewController:drawerController];
        [curController dismissViewControllerAnimated:YES completion:nil];
        return;
    }
    UIViewController *destViewController = [storyboard instantiateViewControllerWithIdentifier:storyboardID];
    [curController.view.window.layer addAnimation:transition forKey:nil];
    //[destViewController.view.layer addAnimation:transition forKey:kCATransition];    
    //[curController presentViewController:destViewController animated:YES completion:nil];
    [appDelegate.window setRootViewController:destViewController];
    [curController dismissViewControllerAnimated:YES completion:nil];
    
}

-(void)LogOut:(UIViewController *)curController
{
    CATransition* transition = [CATransition animation];
    transition.duration = .25;
    transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseOut];
    transition.type = kCATransitionPush;
    transition.subtype = kCATransitionFromRight;
    
    AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    UIViewController *destViewController = [storyboard instantiateViewControllerWithIdentifier:@"SigninViewController"];
    [curController.view.window.layer addAnimation:transition forKey:nil];
    //[destViewController.view.layer addAnimation:transition forKey:kCATransition];
    //[curController presentViewController:destViewController animated:YES completion:nil];
    [curController dismissViewControllerAnimated:YES completion:nil];
    [appDelegate.window setRootViewController:destViewController];
}

@end
