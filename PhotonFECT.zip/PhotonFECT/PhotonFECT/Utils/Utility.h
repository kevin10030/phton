//
//  Utility.h
//  PhotonFECT
//


#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <CoreBluetooth/CoreBluetooth.h>

//iPhone Or iPad
#define isiPhone ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)

//iOS7 Or less
#define ISIOS7 (floor(NSFoundationVersionNumber) > NSFoundationVersionNumber_iOS_6_1)

@interface Utility : NSObject

+ (Utility *)getInstance;
- (void)cmdHideKeyboard:(UITextField*)_txtField;
+(BOOL) IsValidEmail:(NSString *)checkString;
-(void)showToastMessage:(NSString *)message;

+ (void) showProgressDialog:(UIViewController*)controller;
+ (void) hideProgressDialog;

+ (void) setCurrentPeripheral:(CBPeripheral *)peripheral;
+ (CBPeripheral *) getCurrentPeripheral;

+ (void) setCurrentService:(CBService *)service;
+ (CBService *) getCurrentService;

+ (void) setCurrentCharacteristic:(CBCharacteristic *)characteristic;
+ (CBCharacteristic *) getCurrentCharacteristic;


- (UIImage*)circularScaleNCrop:(UIImage*)images  with :(CGRect) rect;
- (UIImage *)scaleAndRotateImage:(UIImage *)image;


-(void)gotoScreen:(UIViewController *)curController :(NSString*)storyboardID;
-(void)LogOut:(UIViewController *)curController;

-(NSString *)getDateTime:(NSString *)str;

@end
