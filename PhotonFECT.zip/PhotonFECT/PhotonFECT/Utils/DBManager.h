//
//  DBManager.h
//  PhotonFECT
//
//  Created by Suju on 9/22/19.
//  Copyright © 2019 Suju. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <sqlite3.h>
#import "ItemModel.h"

@interface DBManager : NSObject {
    NSString *databasePath;
}

+(DBManager*)getSharedInstance;
-(BOOL)createDB;
- (int) saveFavorite:(ItemModel *)model;
- (BOOL) updateFavorite:(ItemModel *)model;
- (BOOL) removeFavorite:(ItemModel *)model;
- (NSArray*) findAllFavorites;
- (ItemModel *)findFavorite:(ItemModel *)model;

@end
