//
//  DBManager.m
//  PhotonFECT
//
//  Created by Suju on 9/22/19.
//  Copyright © 2019 Suju. All rights reserved.
//

#import "DBManager.h"
#import "ItemModel.h"
#import "Preference.h"
#import "Constants.h"

static DBManager *sharedInstance = nil;
static sqlite3 *database = nil;
static sqlite3_stmt *statement = nil;

@implementation DBManager

+(DBManager*)getSharedInstance {
    if (!sharedInstance) {
        sharedInstance = [[super allocWithZone:NULL]init];
        [sharedInstance createDB];
    }
    return sharedInstance;
}

-(BOOL)createDB {
    NSString *docsDir;
    NSArray *dirPaths;
    
    // Get the documents directory
    dirPaths = NSSearchPathForDirectoriesInDomains
    (NSDocumentDirectory, NSUserDomainMask, YES);
    docsDir = dirPaths[0];
    
    // Build the path to the database file
    databasePath = [[NSString alloc] initWithString:
                    [docsDir stringByAppendingPathComponent: @"favorites.db"]];
    BOOL isSuccess = YES;
    NSFileManager *filemgr = [NSFileManager defaultManager];
    
    if ([filemgr fileExistsAtPath: databasePath ] == NO) {
        const char *dbpath = [databasePath UTF8String];
        if (sqlite3_open(dbpath, &database) == SQLITE_OK) {
            char *errMsg;
            const char *sql_stmt = "create table if not exists favorites (id integer primary key autoincrement,email text, name text, color text, desc text)";
            
            if (sqlite3_exec(database, sql_stmt, NULL, NULL, &errMsg) != SQLITE_OK) {
                isSuccess = NO;
                NSLog(@"Failed to create table");
            }
            sqlite3_close(database);
            return  isSuccess;
        } else {
            isSuccess = NO;
            NSLog(@"Failed to open/create database");
        }
    }
    return isSuccess;
}

- (int) saveFavorite:(ItemModel *)model {
    Preference* pref = [Preference getInstance];
    NSString *email = [pref getSharedPreference:nil :PREF_USER_EMAIL :@""];
//    if([email  isEqual: @""]) return 0;
    
    const char *dbpath = [databasePath UTF8String];
    
    if (sqlite3_open(dbpath, &database) == SQLITE_OK) {
        NSString *insertSQL = [NSString stringWithFormat:@"insert into favorites (email,name,color,desc) values(\"%@\",\"%@\", \"%@\", \"%@\")",email, model.name, model.color, model.desc];
    const char *insert_stmt = [insertSQL UTF8String];
    sqlite3_prepare_v2(database, insert_stmt,-1, &statement, NULL);
    
    if (sqlite3_step(statement) == SQLITE_DONE) {
        int rowid = (int)sqlite3_last_insert_rowid(database);
        sqlite3_reset(statement);
        return rowid;
    } else {
        sqlite3_reset(statement);
        return 0;
    }
    
    }
    return 0;
}

- (BOOL) updateFavorite:(ItemModel *)model {
    const char *dbpath = [databasePath UTF8String];
    
    if (sqlite3_open(dbpath, &database) == SQLITE_OK) {
        NSString *updateSQL = [NSString stringWithFormat:@"update favorites set name=\"%@\",color=\"%@\",desc=\"%@\" where id=%d",model.name, model.color, model.desc,model.ID];
        const char *update_stmt = [updateSQL UTF8String];
        sqlite3_prepare_v2(database, update_stmt,-1, &statement, NULL);
        
        if (sqlite3_step(statement) == SQLITE_DONE) {
            sqlite3_reset(statement);
            return YES;
        } else {
            sqlite3_reset(statement);
            return NO;
        }
        
    }
    return NO;
}

- (BOOL) removeFavorite:(ItemModel *)model
{
    const char *dbpath = [databasePath UTF8String];
    
    if (sqlite3_open(dbpath, &database) == SQLITE_OK) {
        NSString *removeSQL = [NSString stringWithFormat:@"delete from favorites where id=%d",model.ID];
        const char *remove_stmt = [removeSQL UTF8String];
        sqlite3_prepare_v2(database, remove_stmt,-1, &statement, NULL);
        
        if (sqlite3_step(statement) == SQLITE_DONE) {
            sqlite3_reset(statement);
            return YES;
        } else {
            sqlite3_reset(statement);
            return NO;
        }
        
    }
    return NO;
}

- (ItemModel *)findFavorite:(ItemModel *)model {
    Preference* pref = [Preference getInstance];
    NSString *email = [pref getSharedPreference:nil :PREF_USER_EMAIL :@""];
    
    const char *dbpath = [databasePath UTF8String];
    
    if (sqlite3_open(dbpath, &database) == SQLITE_OK) {
        NSString *querySQL = [NSString stringWithFormat:@"select * from favorites where email=\"%@\" and name=\"%@\" and color=\"%@\"",email,model.name, model.color];
        const char *query_stmt = [querySQL UTF8String];
        
        if (sqlite3_prepare_v2(database, query_stmt, -1, &statement, NULL) == SQLITE_OK) {
            while (sqlite3_step(statement) == SQLITE_ROW) {
                model.ID = sqlite3_column_int(statement,0);
                sqlite3_reset(statement);
                return model;
            }
            sqlite3_reset(statement);            
        }
    }
    return nil;
}

- (NSArray*) findAllFavorites {
    Preference* pref = [Preference getInstance];
    NSString *email = [pref getSharedPreference:nil :PREF_USER_EMAIL :@""];
    
    const char *dbpath = [databasePath UTF8String];
    
    if (sqlite3_open(dbpath, &database) == SQLITE_OK) {
        NSString *querySQL = [NSString stringWithFormat:@"select * from favorites where email=\"%@\"",email];
        const char *query_stmt = [querySQL UTF8String];
        NSMutableArray *resultArray = [[NSMutableArray alloc]init];
        
        if (sqlite3_prepare_v2(database, query_stmt, -1, &statement, NULL) == SQLITE_OK) {
            while (sqlite3_step(statement) == SQLITE_ROW) {
                ItemModel *model = [[ItemModel alloc] init];
                model.ID = sqlite3_column_int(statement,0);
                model.name = [[NSString alloc] initWithUTF8String:
                                  (const char *) sqlite3_column_text(statement, 2)];
                model.color = [[NSString alloc] initWithUTF8String:
                                        (const char *) sqlite3_column_text(statement, 3)];
                model.desc = [[NSString alloc]initWithUTF8String:
                                  (const char *) sqlite3_column_text(statement, 4)];
                [resultArray addObject:model];
            }
            sqlite3_reset(statement);
            return resultArray;
        }
    }
    return nil;
}
@end

