//
//  Constants.m
//  PhotonFECT
//


#import "Constants.h"

NSString *const PREF_CONNECTION_STATUS = @"connection_status";

NSString *const PREF_TASK_STATUS = @"task_status";
NSString *const TASK_TITLES[4] = {@"New Task",@"Executing...",@"Stopping...",@"Job Stopped"};

NSString *const PREF_DIRECTION_COLOR[8] = {@"direction1_color",@"direction2_color",@"direction3_color",@"direction4_color",@"direction5_color",@"direction6_color",@"direction7_color",@"direction8_color"};

NSString *const LANGUAGE_LOCALE[3] = {@"en",@"zh-Hans",@"zh-Hant"};

NSString *const PREF_LANGUAGE = @"language";
NSString *const PREF_HAND_LOCATION = @"hand_location";
NSString *const PREF_USER_EMAIL = @"user_email";
NSString *const PREF_VERYFIRST_FLAG = @"veryfirst_flag";

NSString *const COMMAND_SENT_COLOR = @"C";
NSString *const COMMAND_STOP = @"S";
NSString *const COMMAND_PAUSE = @"P";
NSString *const COMMAND_ASK_BIO = @"B";

@implementation Constants

@end
