//
//  Constants.h
//  StarRentCar
//


#import <Foundation/Foundation.h>

#define  JOB_NEW_TASK 0
#define  JOB_EXECUTING 1
#define  JOB_STOPPING 2
#define  JOB_STOPPED 3

extern NSString *const PREF_CONNECTION_STATUS;

extern NSString *const PREF_TASK_STATUS;
extern NSString *const TASK_TITLES[4];

extern NSString *const PREF_DIRECTION_COLOR[8];

extern NSString *const LANGUAGE_LOCALE[3];
extern NSString *const PREF_LANGUAGE;
extern NSString *const PREF_HAND_LOCATION;
extern NSString *const PREF_USER_EMAIL;
extern NSString *const PREF_VERYFIRST_FLAG;

extern NSString *const COMMAND_SENT_COLOR;
extern NSString *const COMMAND_STOP;
extern NSString *const COMMAND_PAUSE;
extern NSString *const COMMAND_ASK_BIO;

@interface Constants : NSObject

@end
