//
//  RegisterViewController.m
//  com.homing.eng.alwayshome
//
//  Created by zhaochenghe on 4/1/17.
//  Copyright © 2017 jn. All rights reserved.
//

#import "SignupViewController.h"
#import "Utility.h"
#import "AppDelegate.h"
#import "LocalizeHelper.h"
#import "Preference.h"
#import "Constants.h"

@interface SignupViewController ()

@end

@implementation SignupViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}

-(void)viewDidAppear:(BOOL) animated {
    [super viewDidAppear:animated];
    
    [tfEmail setPlaceholder:LocalizedString(@"Email")];
    [tfPassword setPlaceholder:LocalizedString(@"Password")];
    [tfConfirmPassword setPlaceholder:LocalizedString(@"Confirm Password")];
    
    [btnSignUp setTitle:LocalizedString(@"SIGN UP") forState:UIControlStateNormal];
    [btnSignIn setTitle:LocalizedString(@"ALREADY A MEMBER? SIGN IN") forState:UIControlStateNormal];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)onClickSignup:(id)sender {
//    if(![Utility IsValidEmail:tfEmail.text] ) {
//        [[Utility getInstance] showToastMessage:LocalizedString(@"Please input correct email.")];
//        return;
//    }
//    if([tfPassword.text isEqualToString:@""]) {
//        [[Utility getInstance] showToastMessage:LocalizedString(@"Please input your password.")];
//        return;
//    }
//
//    if(![tfConfirmPassword.text isEqualToString:tfPassword.text]) {
//        [[Utility getInstance] showToastMessage:LocalizedString(@"Please confirm your password.")];
//        return;
//    }
//    
//    Preference* pref = [Preference getInstance];
//    [pref putSharedPreference:nil :PREF_USER_EMAIL :tfEmail.text];

    [[Utility getInstance] gotoScreen:self :@"MainViewController"];
    
}



- (IBAction)onClickToLogin:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/



#pragma mark -
#pragma mark UITouch Methods

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    
    [[Utility getInstance] cmdHideKeyboard:txtfControl];
    
}

#pragma mark -
#pragma mark UITextFieldDelegate Methods

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    
    txtfControl = textField;
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [[Utility getInstance] cmdHideKeyboard:textField];
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    
//    NSString *str = [[textField text] stringByReplacingCharactersInRange:range withString:string];
    
    
    return true;
}


@end
