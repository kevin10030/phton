//
//  RegisterViewController.h
//  com.homing.eng.alwayshome
//
//  Created by zhaochenghe on 4/1/17.
//  Copyright © 2017 jn. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SignupViewController : UIViewController<UITextFieldDelegate>
{
    UITextField *txtfControl;
    
    IBOutlet UITextField *tfEmail;
    IBOutlet UITextField *tfPassword;
    IBOutlet UITextField *tfConfirmPassword;
    
    IBOutlet UIButton *btnSignUp;
    IBOutlet UIButton *btnSignIn;
}
@end
