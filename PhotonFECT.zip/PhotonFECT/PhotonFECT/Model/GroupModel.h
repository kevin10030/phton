//
//  GroupModel.h
//  PhotonFECT
//
//  Created by Suju on 8/1/19.
//  Copyright © 2019 Suju. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ItemModel.h"

@interface GroupModel : NSObject

@property (nonatomic, strong) NSString* name;
@property (nonatomic, retain) NSMutableArray* groupArray;
@property (nonatomic, retain) NSMutableArray* itemArray;

-(instancetype)initWithDictionary:(NSDictionary*) dict;
@end
