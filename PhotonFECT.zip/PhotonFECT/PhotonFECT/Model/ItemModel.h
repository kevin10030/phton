//
//  ItemModel.h
//  PhotonFECT
//
//  Created by Suju on 8/1/19.
//  Copyright © 2019 Suju. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ItemModel : NSObject

@property(nonatomic, assign)  int ID;
@property (nonatomic, strong) NSString* name;
@property (nonatomic, strong) NSString* color;
@property (nonatomic, strong) NSString* desc;
@end
