//
//  GroupModel.m
//  PhotonFECT
//
//  Created by Suju on 8/1/19.
//  Copyright © 2019 Suju. All rights reserved.
//

#import "GroupModel.h"

@implementation GroupModel

-(instancetype)initWithDictionary:(NSDictionary*) dict{
    self = [super init];
    if(self) {
        self.groupArray = [[NSMutableArray alloc] init];
        self.itemArray = [[NSMutableArray alloc] init];

        @try{ self.name = [dict objectForKey:@"name"]; }@catch(NSException *e){}
        NSArray *items = [dict objectForKey:@"i"];
        for (NSDictionary *item in items) {
            ItemModel *itemModel = [[ItemModel alloc] init];
            itemModel.ID = 0;
            itemModel.name = [item objectForKey:@"name"];
            itemModel.color = [item objectForKey:@"color"];
            itemModel.desc = [item objectForKey:@"desc"];
            [self.itemArray addObject:itemModel];
        }
        
        NSArray *groups = [dict objectForKey:@"g"];
        for (NSDictionary *group in groups) {
            GroupModel *groupModel = [[GroupModel alloc] initWithDictionary:group];
            [self.groupArray addObject:groupModel];
        }
    }
    return self;
}

@end


