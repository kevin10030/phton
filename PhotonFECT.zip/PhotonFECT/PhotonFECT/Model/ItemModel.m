//
//  ItemModel.m
//  PhotonFECT
//
//  Created by Suju on 8/1/19.
//  Copyright © 2019 Suju. All rights reserved.
//

#import "ItemModel.h"

@implementation ItemModel

@end
